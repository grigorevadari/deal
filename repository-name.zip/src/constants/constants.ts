export const ITEM_HEIGHT = 50; // Fixed height for each item
export const VISIBLE_ITEMS = 10; // Number of items to display at once