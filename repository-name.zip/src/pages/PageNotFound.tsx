import React from "react";
import NotFound from "../components/NotFound/notFound";

const NotFoundPage: React.FC = () => {
    return <NotFound/>;
};

export default NotFoundPage;
