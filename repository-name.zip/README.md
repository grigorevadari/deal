# Deal test task


#### Setup

    // install nodejs
    npm i

    // build
    npm run build
   
    // local run
    npm start
